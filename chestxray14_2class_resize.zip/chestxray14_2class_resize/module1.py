from torchvision import transforms
import warnings
import cv2
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")


path = "D:\\mokaiwei\\dataset\\chestxray14_2class_resize1\\images-2class\\"
def xray2_load_data():
    train_data = pd.read_csv('D:\\mokaiwei\\dataset\\chestxray14_2class\\train_new_2class.txt', header=None, index_col=None)[0].str.split(' ', 1)
    train_labels = np.vstack(train_data.apply(lambda x: max(x[1].split())).values).astype(np.int8)[:32233]
    #print('train labels: ' + str(train_labels))
    train_images = train_data.apply(lambda x: 'D:\\mokaiwei\\dataset\\chestxray14_2class\\images-2class\\' + x[0]).values[:32233]
    val_data = pd.read_csv('D:\\mokaiwei\\dataset\\chestxray14_2class\\val_new_2class.txt', header=None, index_col=None)[0].str.split(' ', 1)
    val_labels = np.vstack(val_data.apply(lambda x: max(x[1].split())).values).astype(np.int8)[:3572]
    val_images = val_data.apply(lambda x: 'D:\\mokaiwei\\dataset\\chestxray14_2class\\images-2class\\' + x[0]).values[:3572]
    train_labels = train_labels.reshape(len(train_labels),)
    val_labels = val_labels.reshape(len(val_labels),)
    return train_images, train_labels, val_images, val_labels

x_train_address, y_train, x_test_address, y_test = xray2_load_data()
train_data = pd.read_csv('D:\\mokaiwei\\dataset\\chestxray14_2class\\train_new_2class.txt', header=None, index_col=None)[0].str.split(' ', 1)
val_data = pd.read_csv('D:\\mokaiwei\\dataset\\chestxray14_2class\\val_new_2class.txt', header=None, index_col=None)[0].str.split(' ', 1)

for i in range(len(x_train_address)):
    img = cv2.imread(x_train_address[i])
    x, y = img.shape[0:2]
    img2 = cv2.resize(img, (32, 32))
    cv2.imwrite(path+train_data[i][0], img2)

for i in range(len(x_test_address)):
    img = cv2.imread(x_test_address[i])
    x, y = img.shape[0:2]
    img2 = cv2.resize(img, (32, 32))
    cv2.imwrite(path+val_data[i][0], img2)
